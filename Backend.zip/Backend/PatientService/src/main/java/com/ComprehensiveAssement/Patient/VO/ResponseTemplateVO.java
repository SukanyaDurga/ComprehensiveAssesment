package com.ComprehensiveAssement.Patient.VO;

import com.ComprehensiveAssement.Patient.Entity.Patients;

import lombok.Data;

@Data
public class ResponseTemplateVO {
	private Patients patients ;
	private Doctors doctors ;
	
	public ResponseTemplateVO() {
		super();
	}
	public ResponseTemplateVO(Patients patients, Doctors doctors) {
		super();
		this.patients = patients;
		this.doctors = doctors;
	}
	public Patients getPatients() {
		return patients;
	}
	public void setPatients(Patients patients) {
		this.patients = patients;
	}
	public Doctors getDoctors() {
		return doctors;
	}
	public void setDoctors(Doctors doctors) {
		this.doctors = doctors;
	}
	


}
