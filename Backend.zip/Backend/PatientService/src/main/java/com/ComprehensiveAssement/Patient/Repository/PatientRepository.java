package com.ComprehensiveAssement.Patient.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ComprehensiveAssement.Patient.Entity.Patients;

@Repository
public interface PatientRepository extends JpaRepository<Patients ,Integer>{

	Patients findByPatientId(int patientId);

	

	List<Patients> findByDoctorName(String doctorName);

	

}
