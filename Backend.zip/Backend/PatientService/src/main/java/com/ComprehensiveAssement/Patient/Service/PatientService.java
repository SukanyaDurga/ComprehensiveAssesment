package com.ComprehensiveAssement.Patient.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ComprehensiveAssement.Patient.Entity.Patients;
import com.ComprehensiveAssement.Patient.Repository.PatientRepository;
import com.ComprehensiveAssement.Patient.VO.Doctors;
import com.ComprehensiveAssement.Patient.VO.ResponseTemplateVO;

@Service
public class PatientService {

	@Autowired
	private PatientRepository patientRepository ;
	@Autowired
	private RestTemplate  restTemplate ;
	

	public Patients savePatient(Patients patient) {
		
		return patientRepository.save(patient);
	}

	public ResponseTemplateVO getPatientWithDoctor(int patientId) {
		ResponseTemplateVO vo = new ResponseTemplateVO();
		Patients patients = patientRepository.findByPatientId(patientId) ;
		Doctors doctors = 
		      restTemplate.getForObject("http://localhost:9001/DoctorsByName/"+patients.getDoctorName()
		      , Doctors.class) ;
		vo.setPatients(patients);
		vo.setDoctors(doctors);
		
		return vo ;
		
	}

	public int getPatientByDoctorName(String doctorName) {
		 
		List<Patients> patients =new ArrayList<>();
		patients = patientRepository.findByDoctorName(doctorName);
		return patients.size();
	}

	public List<Patients> getAllPatients() {
		List<Patients> patients =new ArrayList<>();
	     patientRepository.findAll().forEach(patients :: add);
		return patients;
	}

	public Patients findPatientById(int patientId) {
		return  patientRepository.findByPatientId(patientId)  ;
	}

	

	
	
	


}
