package com.ComprehensiveAssement.Patient.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.ComprehensiveAssement.Patient.Entity.Patients;
import com.ComprehensiveAssement.Patient.Service.PatientService;
import com.ComprehensiveAssement.Patient.VO.ResponseTemplateVO;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class PatientController {
	@Autowired
	private PatientService patientService ;
	
	@PostMapping("/Patients")
	public Patients createPatient(@RequestBody Patients patient)
	{
		return patientService.savePatient(patient);
	}
	@GetMapping("/Patients")
	 public List<Patients> getPatientList()
	   {
		  return (patientService.getAllPatients() );
	   }

	@GetMapping("/Patients/{patientId}")
	public Patients getPatientById(@PathVariable("patientId") int patientId)
	{
		return patientService.findPatientById(patientId);
	}
	
	@RequestMapping(value="/PatientsWthDoctor/{patientId}" ,method=RequestMethod.GET)
	public ResponseTemplateVO getPatientWithDoctor( @PathVariable("patientId") int patientId)
	{
		return patientService.getPatientWithDoctor(patientId);
	}
	
	@GetMapping("/PatientsByDoctorName/{doctorName}")
	public int GetPatientByDoctorName(@PathVariable String doctorName)
	{
		return patientService.getPatientByDoctorName(doctorName);
	}
	

}
